export interface User {
  userId: number;
  first_name: string;
  last_name: string;
  email: string;
  password: string;
  phone_number: string;
  role: string;
}
