export interface DisplayReviews {
  ratings: string,
  review: string,
  submittedDate: string,
  restaurant: string,
  author: number,
  reviewTitle: string,
  restaurant_name: string
}
