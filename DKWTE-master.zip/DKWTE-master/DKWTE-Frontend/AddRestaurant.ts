export interface NewRestaurant {
  id: string,
  name: string,
  address: string
}
