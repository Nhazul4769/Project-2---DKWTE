import 'hammerjs';
