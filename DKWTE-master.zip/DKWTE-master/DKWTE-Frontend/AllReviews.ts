export interface AllReviews {
  reviewId: number,
  ratings: string,
  review: string,
  reviewTitle: string,
  submittedDate: string,
  restaurant_name: string,
  authorId: number
}
