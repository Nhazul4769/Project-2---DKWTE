export interface Ratings {
      id: number,
      icon: string,
      class: string

}
